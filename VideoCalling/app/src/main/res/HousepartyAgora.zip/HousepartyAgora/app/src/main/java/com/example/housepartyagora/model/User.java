package com.example.housepartyagora.model;

public class User {
    private int agoraUid;

    public User () {

    }

    public int getAgoraUid() {
        return agoraUid;
    }

    public void setAgoraUid(int agoraUid) {
        this.agoraUid = agoraUid;
    }
}
