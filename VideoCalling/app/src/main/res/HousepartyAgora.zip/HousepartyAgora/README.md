# HousepartyAgora

Find the step-by-step tutorial here: 
https://medium.com/@shaocheng.yang1995/how-to-build-a-drop-in-video-chat-application-using-android-54a27b0b07ce
